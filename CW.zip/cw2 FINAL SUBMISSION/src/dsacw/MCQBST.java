
package dsacw;


import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.io.FileReader;
import java.io.BufferedReader;



/**
 *
 * @author Euan William Martin
 */
    public class MCQBST  {    
            BinarySearchTree<MCQ> bst;
            MCQBST() {
                // put your constructor code here to initialise any class fields etc
                bst = new BinarySearchTree<>();
                loadData();
            }

            void loadData(){
                try{
                    BufferedReader br = new BufferedReader(new FileReader("Questions.txt"));
                    String line;
                    while((line = br.readLine()) != null){
                        MCQ mcq = new MCQ();
                        mcq.setId(Integer.parseInt(line));
                        mcq.setTypeOfQuestion(Integer.parseInt(br.readLine()));
                        mcq.setAuthor(br.readLine());
                        mcq.setAvailable(br.readLine().equals("True"));
                        mcq.setQuestion(br.readLine());
                        bst.add(mcq);
                        br.readLine();
                    };
                } catch(IOException e){
                    e.printStackTrace();
                }
            }

            void displayInAscending(){
                System.out.println(bst.inorderToString());
            }

//Descending?? how         

            void displayAvailableMCQ(){
                List<MCQ> List = bst.toList();
                for(MCQ mcq : List){
                    if(mcq.isAvailable()){
                        System.out.println(mcq);
                    }
                }
            }

        void displayAuthorNames(){
                List<MCQ> List = bst.toList();
                for(MCQ mcq : List){
                    System.out.println(mcq.getAuthor());
                }
        }
    }
