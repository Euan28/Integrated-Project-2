
package dsacw;

/**
 *
 * @author Euan William Martin
 */
public class TestPart4 {
    
    TestPart4() {
        // put your constructor code here to initialise any class fields           
    }
    
    public void run() {
        System.out.println("Part4 started --- Pulling it all together\n");
        // put your code here to pull all the stuff together 
        System.out.println("build your menu and start using all your pre-built code");
        System.out.println("\nPart4 completed");
        System.out.println("==============================================\n");
    
        
    }

// if you need some class fields so put them here

}