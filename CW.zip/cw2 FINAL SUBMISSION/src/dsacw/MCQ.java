package dsacw;


import java.util.Comparator;

/**
 *
 * @author Euan William Martin
 */
    public class MCQ implements Comparable<MCQ> {

            private int id;
            private int typeOfQuestion;
            private String authorName;
            private boolean available;
            private String question;

            // Cnstructor doesnt take in any arguments
            MCQ() {
            }
            // you need some class fields so put them here
            public int getId() {
                return id;
            }

            public void setId(int ID) {
                this.id = id;
            }

            public int getTypeOfQuestion() {
                return typeOfQuestion;
            }

            public void setTypeOfQuestion(int typeOfQuestion) {
                this.typeOfQuestion = typeOfQuestion;
            }

            public String getAuthor() {
                return authorName;
            }

            public void setAuthor(String authorName) {
                this.authorName = authorName;
            }

            public boolean isAvailable() {
                return available;
            }

            public void setAvailable(boolean available) {
                this.available = available;
            }

            public String getQuestion() {
                return question;
            }

            public void setQuestion(String question) {
                this.question = question;
            }

            @Override
            public String toString() {
                return "MCQ{" + "id=" + id + ", typeOfQuestion=" + typeOfQuestion + ", author=" + authorName + ", available=" + available + ", question=" + question + '}';
            }

            @Override
            public int compareTo(MCQ o) {
                return (this.id-o.id);
            }

    }
          
