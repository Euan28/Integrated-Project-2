package dsacw;

/**
 *
 * @author Euan William Martin
 */
    public class TestPart3 {

        TestPart3() {
            // put your constructor code here to initialise any class members etc          
        }

            public void run() {
                    System.out.println("Part3 started --- Tests for the MCQ BST class\n");
                    // put your code here to test the MCQ BST that you built  
                    MCQBST mcqBST = new MCQBST();
                    System.out.println("\nAscending Order");
                    mcqBST.displayInAscending();
                    System.out.println("\nAvailable MCQ's");
                    mcqBST.displayAvailableMCQ();
                    System.out.println("\nAuthor Names");
                    mcqBST.displayAuthorNames();
                    System.out.println("\nPart3 completed");
                    System.out.println("==============================================\n");
            }

        // you might need some class fields so put them here
    }
