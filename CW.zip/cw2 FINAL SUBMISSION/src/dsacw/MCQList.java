
package dsacw;

/**
 *
 * @author Euan William Martin
 * 
 * remember this class should implement the IADTMCQ interface
 */
    public class MCQList implements IADTMCQ { 

        Node head, tail;
        MCQList() {
                // put your constructor code here to initialise any class fields           
                head = null;
            }    

        @Override
            public void addMCQ(MCQ mcq) {
                Node newNode = new Node(mcq);
                if(head == null){
                    head = tail = newNode;
                } else{
                    tail.next = newNode;
                    tail = newNode;
                }
            }

        @Override
        public void askMCQ(MCQ mcq) {
                System.out.println(mcq.getQuestion());
                if(mcq.getTypeOfQuestion() == '1'){
                    System.out.println("a. True\t" + "b. False" );
                }
            }

        @Override
        public MCQ searchMCQ(int mcqId) {
                Node temp = head;
                while(temp != null){
                    if(temp.data.getId() == mcqId){
                        return temp.data;
                    }
                    temp = temp.next;
                }
                return null;
            }

        @Override
        public MCQ searchMCQ(String authorName) {
                Node temp = head;
                while(temp != null){
                    if(temp.data.getAuthor().equals(authorName)){
                        return temp.data;   
                    }
                    temp = temp.next;
                }
                return null;
            }

        @Override
        public void makeMCQAvailable(int mcqId, boolean available) {
                Node temp = head;
               while(temp != null){
                   if(temp.data.getId() == mcqId){
                       temp.data.setAvailable(available);
                       break;
                   }
                   temp = temp.next;
               }
           }

        @Override
        public void displayMCQList() {
                Node temp = head;
                while(temp != null){
                    askMCQ(temp.data);
                    temp = temp.next;
                }
            }

        class Node{
                MCQ data;
                Node next;
                Node(MCQ mcq) {
                    this.data = mcq;
                    next = null;
                }
            }
    }
