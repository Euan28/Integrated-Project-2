package dsacw;

/**
 *
 * @author Euan William Martin
 */
    public class TestPart2 {

        TestPart2() {
            // put your constructor code here to initialise any class stuff           
        }

            public void run() {
                    System.out.println("Part2 started --- Tests for the MCQList class\n");
                    // put your code here to work with the MCQList class that you built
                    MCQList mcqList = new MCQList();

                    MCQ mcq1 = new MCQ();
                    mcq1.setId(1);
                    mcq1.setQuestion("Question 1");
                    mcq1.setAuthor("Author 1");
                    mcq1.setTypeOfQuestion(1);
                    mcq1.setAvailable(true);
                    mcqList.addMCQ(mcq1);
                    mcqList.searchMCQ(1);
                    mcqList.searchMCQ("Author 1");
                    mcqList.makeMCQAvailable(1, false);

                    mcqList.displayMCQList();

                    System.out.println("\nPart2 completed");
                    System.out.println("==============================================\n");
            }

            // if you need some class fields you can put them here
    }
